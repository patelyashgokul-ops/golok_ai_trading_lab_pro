# Golok AI Trading Lab Pro

P09.1 connects **Fixture Research Cycles** to **Prospective Fixture Paper Accounts**. Bound schedules share one risk budget and process later authored candles. **Synthetic Strategy Performance** reports frozen marks, and **Synthetic Walk-forward Experiments** records promotion evidence. [P09 development report](DEVELOPMENT_REPORT.md) · [ગુજરાતી સેટઅપ](docs/OWNER_SETUP_GUJARATI.md)

P08 adds **Research Schedules**, **Daily Research Operations**, **Compare Sources** and publisher-specific data authorization. The local fixture workflow works without a broker account. **Run Synthetic Portfolio** uses shared virtual capital and records input hashes, fees and decision gates. [Owner actions](docs/OWNER_ACTION_REQUIRED.md)

An Odoo 20 Community add-on for historical NSE and BSE equity research. P03 adds effective-dated reference records, split-session calendar validation, supplemental research, bounded synthetic ST-01 experiments in Odoo, and a virtual historical replay journal. Historical analytical snapshots remain **NO TRADE**.

## Install and use

1. Install Odoo 20 Community and PostgreSQL using the Odoo source distribution’s dependencies. The add-on needs no extra Python packages at runtime. Put the module directory on Odoo's `addons_path`, restart Odoo and update the Apps list.
2. Install **Golok AI Trading Lab Pro**. Assign a user the Trading System Administrator role to register instruments, Trading Research Analyst to import and run research, or Trading Research Viewer for read access. Use the intended active company. Users who want market time in native Odoo fields can select **Asia/Kolkata** in their preferences.
3. In **Trading Lab → Instruments**, register the NSE or BSE instrument. In **Datasets**, select the instrument, interval and provenance. For real local CSV, the publisher must match the active authorization under **Source Authorizations**. Choose **Synthetic fixture** for generated data.
4. In **Import CSV**, select the dataset and upload a UTF-8 file with the following header. The example uses a fictitious observation.

   ```csv
   close_time,open,high,low,close,volume
   2024-01-02T09:20:00+05:30,100,102,99,101,1000
   ```

   Use candle close times with an explicit time offset and zero seconds. Supply ascending, unique timestamps. Maximum upload is 512 KiB or 4,000 rows. An identical re-import adds zero duplicates. A conflicting observation requires a distinct source revision.
5. For point-in-time research, create an immutable revision in **Exchange Calendars** and select it when registering a new dataset. Follow the [calendar contract](docs/EXCHANGE_CALENDAR.md) to include explicit opening and publication times. Legacy datasets retain the six-column import and original research digest.
6. In **Run Research**, choose the dataset and a cutoff, then open the result. In **Overview**, use **Show historical chart** to display up to 60 observations from the latest intact snapshot. Company counts, ingestion time, quarantine status and the research-only decision are server-backed.

Run the synthetic [ST-01 replay](docs/BACKTEST_EXECUTION_POLICY.md) with the provided fixture:

```powershell
python -B scripts/run_backtest.py tests/fixtures/p02/spec.json tests/fixtures/p02/candles.csv
```

Trading Risk Managers can use **Post Replay** to post a completed synthetic experiment to a historical virtual account. The separate prospective fixture workspace processes authored observations automatically when bound to schedules and also supports manual scenarios. Real trading remains disabled. [Historical ledger](docs/PAPER_LEDGER_INVARIANTS.md) · [Prospective fixtures](docs/P09_PAPER_TRADING_REPORT.md)

The [SmartAPI diagnostics](docs/SMARTAPI_SETUP.md) are offline by default. Authorized broker verification is pending.

## Verify

P03 uses PostgreSQL's bundled `btree_gist` extension for effective-date constraints. The Odoo database role must be able to create this trusted extension in the database, or the database administrator can install it beforehand.

Run `python -B -m unittest discover -s tests -p "unit_*.py" -v` from the add-on root. On Windows, run `./scripts/verify_odoo.ps1` for disposable verification. Add `-Browser` for Playwright and Edge. Run the harness directly and avoid piping the entire script. The parameterized `scripts/verify_p01_upgrade.ps1` clones a disposable populated database as its migration target.

See [Development report](DEVELOPMENT_REPORT.md) and [architecture](docs/ARCHITECTURE.md).
